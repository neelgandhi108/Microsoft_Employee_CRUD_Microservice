﻿using Microsoft.AspNetCore.Mvc;
using Microsoft_Employee_CRUD_Microservice.Models.Domain;
using Microsoft_Employee_CRUD_Microservice.Services;

namespace Microsoft_Employee_CRUD_Microservice.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly IEmployeeService _employeeService;

        public EmployeeController(IEmployeeService employeeService)
        {
            _employeeService = employeeService;
        }

        public IActionResult Index()
        {
            ViewBag.prompt = "Design a microservice for CRUD operations on billions of Employee entities, ensuring high request-per-second (RPS) capability and public API exposure.";
            ViewData["prompt2"] = "Deliverables include a design document with assumptions, high-level architecture, and a GitHub repository link containing controllers and interfaces for backend operations, guided by Microsoft's ASP.NET MVC Controller Overview.";
            //ViewBag and ViewData can send data only from ControllerToView

            //Tempdata can send data from one controller method to another controller method
            TempData["prompt3"] = "Include test case outlines for each CRUD API, focusing on scalability and robustness, with implementation in C# or Java preferred.";
            return View();
        }

        public IActionResult AddEmployee()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddEmployee(Employee employee)
        {
            if (!ModelState.IsValid)
            {
                return View();
            }

            try
            {
                _employeeService.AddEmployee(employee);
                TempData["msg"] = "Added successfully";
                return RedirectToAction("AddEmployee");
            }
            catch (Exception ex)
            {
                TempData["msg"] = "Could not add!";
                return View();
            }
        }

        public IActionResult DisplayEmployees()
        {
            var employees = _employeeService.GetAllEmployees();
            return View(employees);
        }

        public IActionResult EditEmployee(int id)
        {
            var employee = _employeeService.GetEmployeeById(id);
            return View(employee);
        }

        [HttpPost]
        public IActionResult EditEmployee(Employee employee)
        {
            if (!ModelState.IsValid)
            {
                return View();
            }

            try
            {
                _employeeService.UpdateEmployee(employee);
                return RedirectToAction("DisplayEmployees");
            }
            catch (Exception ex)
            {
                TempData["msg"] = "Could not update!";
                return View();
            }
        }

        public IActionResult DeleteEmployee(int id)
        {
            try
            {
                _employeeService.DeleteEmployee(id);
            }
            catch (Exception ex)
            {
                // Handle exception
            }
            return RedirectToAction("DisplayEmployees");
        }
    }
}


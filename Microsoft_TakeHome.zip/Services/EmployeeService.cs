﻿using Microsoft_Employee_CRUD_Microservice.Models.Domain;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Microsoft_Employee_CRUD_Microservice.Services
{
    public class EmployeeService : IEmployeeService
    {
        private readonly DatabaseContext _ctx;

        public EmployeeService(DatabaseContext ctx)
        {
            _ctx = ctx;
        }

        public List<Employee> GetAllEmployees()
        {
            return _ctx.Employees.ToList();
        }

        public Employee GetEmployeeById(int id)
        {
            return _ctx.Employees.Find(id);
        }

        public void AddEmployee(Employee employee)
        {
            _ctx.Employees.Add(employee);
            _ctx.SaveChanges();
        }

        public void UpdateEmployee(Employee employee)
        {
            _ctx.Employees.Update(employee);
            _ctx.SaveChanges();
        }

        public void DeleteEmployee(int id)
        {
            var employee = _ctx.Employees.Find(id);
            if (employee != null)
            {
                _ctx.Employees.Remove(employee);
                _ctx.SaveChanges();
            }
        }
    }
}
